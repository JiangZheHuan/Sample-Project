import requests
from bs4 import BeautifulSoup as Soup
import openpyxl as xl
from openpyxl import Workbook
from openpyxl import load_workbook
import time

# selenium
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.action_chains import ActionChains
import selenium.webdriver.support.ui as ui


links = 'dismay.html'
DRIVER_PATH = 'chromedriver_linux64/chromedriver'
dismay_categories = {}
brasilybelleza_categories = {}

sublime_bw_categories = {'CABELLO - Extensiones': 'https://sublimebw.com/4489-extensiones',
                         'Estetica': 'https://sublimebw.com/162-estetica',
                         'Utillaje': 'https://sublimebw.com/148-utillaje'}

headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0",
           "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
           "Accept-Language": "en-US,en;q=0.9"
           }
# save data for brasilybelleza
wb_brasilybelleza = Workbook()
ws_brasilybelleza = wb_brasilybelleza.active
product_brasilybelleza = 'product_brasilybelleza.xlsx'
sheet_title = 'products'
ws_brasilybelleza.append(["Cores", "sku", "Sku_parent", "post_title", "tax:product_cat", "tax:product_tag",
                          "tax:product_brand", "post_content", "cost_of_good", "weight", "post_excerpt", "regular_price",
                          "sale_price", "tax_status", "stock", "manage_stock", "stock_status", "images", "image_files",
                          "meta:Image Title", "meta:Image Description", "meta:Image Alt Text", "Permalink", "Status",
                          "Slug"])
wb_brasilybelleza.save(product_brasilybelleza)

# save data for dismay
wb_dismay = Workbook()
ws_dismay = wb_dismay.active
product_dismay = 'product_dismay2.xlsx'
sheet_title = 'products'
ws_dismay.append(["Cores", "sku", "Sku_parent", "post_title", "tax:product_cat", "tax:product_tag",
                  "tax:product_brand", "post_content", "cost_of_good", "weight", "post_excerpt", "regular_price",
                  "sale_price", "tax_status", "stock", "manage_stock", "stock_status", "images", "image_files",
                  "meta:Image Title", "meta:Image Description", "meta:Image Alt Text", "Permalink", "Status",
                  "Slug"])
wb_dismay.save(product_dismay)

# save worksheet for sublime_bw
wb_sublime_bw = Workbook()
ws_sublime_bw = wb_sublime_bw.active
product_sublime_bw = 'product_sublime_bw2.xlsx'
sheet_title = 'products'
ws_sublime_bw.append(["Cores", "sku", "Sku_parent", "post_title", "tax:product_cat", "tax:product_tag",
                      "tax:product_brand", "post_content", "cost_of_good", "weight", "post_excerpt", "regular_price",
                      "sale_price", "tax_status", "stock", "manage_stock", "stock_status", "images", "image_files",
                      "meta:Image Title", "meta:Image Description", "meta:Image Alt Text", "Permalink", "Status",
                      "Slug"])
wb_sublime_bw.save(product_sublime_bw)


# this method will scrape dismay data
def get_dismay():
    login_link = 'https://shop.dismay.es/inicio-sesion?back=my-account'
    login_email = 'cjbusquet@gmail.com'
    login_password = 'godo3606'

    # login into website
    options = webdriver.ChromeOptions()
    options.add_argument('--headless')
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-dev-shm-usage')
    driver = webdriver.Chrome('chromedriver', options=options)
    try:
        driver.get(login_link)
        time.sleep(4)
    except:
        time.sleep(10)
        pass
    time.sleep(1)

    # enter email/password
    driver.find_element_by_id("email").send_keys(login_email)
    driver.find_element_by_id("passwd").send_keys(login_password)

    login_click = ActionChains(driver)
    login_click.click(driver.find_element_by_id('SubmitLogin')).perform()

    # get all categories
    link_url = "https://shop.dismay.es/"
    response_ = requests.get(url=link_url, headers=headers)
    data_soup = Soup(response_.text, "html.parser")
    # print(data_soup)
    categories = data_soup.find('ul', {'class:', 'list-block list-group bullet tree dhtml'})
    for category in categories.findAll('li'):
        cat_name = category.find('a').text
        cat_url = category.find('a')['href']
        # save categories to dictionary
        dismay_categories[cat_name] = cat_url

    time.sleep(2)
    # getting each category
    for key in dismay_categories:
        url_length = 0
        time.sleep(5)
        print(key + ' : ' + dismay_categories[key] + '\n\n')
        cat_url = dismay_categories[key]
        cat_response = requests.get(url=cat_url, headers=headers)
        # checking for subcategories
        if 'subcategories' in cat_response.text:
            print("its have sub")
        else:
            # get all pages in a category
            cat_soup = Soup(cat_response.text, "html.parser")
            try:
                cat_pages = cat_soup.find('ul', {'class:', 'pagination pull-left'})
                if cat_pages is None:
                    url_length = 1
                else:
                    page_length = len(cat_pages.findAll('a'))
                    page_length = link_url + cat_pages.findAll('a')[page_length-2]['href']
                    url_length = len(page_length)
                    url_length = page_length[url_length-1]
            except:
                url_length = 1

        # get product page url for each product in a page
        try:
            for page_ in range(int(url_length)):
                page_url = cat_url + '?p=' + str(page_ + 1)
                time.sleep(2)
                print("Page URL: " + page_url)
                products_response = requests.get(url=page_url, headers=headers)
                products_soup = Soup(products_response.text, "html.parser")
                products = products_soup.find('div', {'class:', 'product_list grid row'})

                # product details
                for product in products.findAll('div', {'class:', 'product-container'}):
                    product_url = product.find('a', {'class:', 'product_img_link'})
                    time.sleep(1)
                    # product details page / detail page url
                    d_url = product_url['href']

                    driver.get(d_url)
                    time.sleep(1)
                    details_soup = Soup(driver.page_source, "html.parser")
                    time.sleep(1)
                    # products_details = requests.get(url=d_url, headers=headers)
                    # details_soup = Soup(products_details.text, "html.parser")
                    all_category = details_soup.find('span', {'class:', 'navigation_page'})

                    # check if product in sub category
                    check_sub_category = len(all_category.findAll('span'))
                    if check_sub_category > 3:
                        category_name = all_category.findAll('span')[0].text
                        sub_cat_name = all_category.findAll('span')[3].text

                    else:
                        category_name = all_category.findAll('span')[0].text
                        sub_cat_name = ''

                    product_section = details_soup.find('div', {'class:', 'primary_block row'})

                    # product image
                    image_src = product_section.find('img')['src']
                    image_title = product_section.find('img')['title']
                    image_alt = product_section.find('img')['alt']

                    # product name
                    product_name = product_section.find('h1').text

                    # Brand and Reference
                    try:
                        for brand_reference in product_section.findAll('p'):
                            if 'Marca' in brand_reference.text or 'Brand' in brand_reference.text:
                                brand_name = brand_reference.text
                            if 'Referencia' in brand_reference.text or 'Reference' in brand_reference.text:
                                reference_name = brand_reference.text
                    except:
                        brand_name = ''
                        reference_name = ''

                    # short description
                    try:
                        short_description = product_section.find('div', {'id': 'short_description_content'})
                        short_description = short_description.text
                    except:
                        short_description = ''

                    # detail description
                    try:
                        long_description = details_soup.find('div', {'class:', 'more_info_block'})
                        long_description = long_description.find('div', {'class:', 'tab-content'})
                        long_description = long_description.text
                    except:
                        long_description = ''

                    slug_ = d_url.split('/')[4]
                    product_tag = details_soup.find('span', {'class:', 'navigation_page'}).text
                    product_tag = product_tag.replace('>', ' | ')

                    reference_name = reference_name.replace('Referencia: ', '')
                    brand_name = brand_name.replace('Marca: ', '')

                    price = details_soup.find('div', {'class:', 'price'})

                    try:
                        old_price = price.find('p', {'id': 'old_price'}).text.strip()
                    except:
                        old_price = ''

                    try:
                        new_price = price.find('p', {'class:', 'our_price_display'}).text.strip()

                        if 'IVA no incluido' in new_price:
                            new_price = new_price.replace('IVA no incluido', '')
                    except:
                        new_price = ''

                    try:
                        color_attributes = product_section.find('div', {'id': 'attributes'})

                        cores_color = color_attributes.find('div', {'class:', 'attribute_list'})
                        cores_color = cores_color.find('select')

                        for core_ in cores_color.findAll('option'):
                            option_color = core_['title']
                            option_sku_value = core_['value']

                            if parent_slug_sku == '':
                                parent_slug_sku = option_sku_value

                            ws_dismay.append([option_color, option_sku_value, parent_slug_sku, product_name,
                                              category_name + ' ' + sub_cat_name,
                                              product_tag, brand_name, long_description, new_price, "",
                                              short_description,
                                              old_price, new_price, "", "", "", "", image_src,
                                              image_title, image_title, image_title, image_alt, d_url, "Status",
                                              slug_])
                            wb_dismay.save(product_dismay)

                    except:
                        print("no color")

                    ws_dismay.append(
                        ["", reference_name, parent_slug_sku, product_name, category_name + ' ' + sub_cat_name,
                         product_tag, brand_name, long_description, new_price, "", short_description,
                         old_price, new_price, "", "", "", "", image_src,
                         image_title, image_title, image_title, image_alt, d_url, "", slug_])
                    wb_dismay.save(product_dismay)

        except:
            pass
    driver.quit()


# method for scrapping sublime data
def get_sublime_bw():
    # login into website
    login_link = 'https://sublimebw.com/iniciar-sesion?back=my-account'
    login_email = 'cjimenez@equipcosmedic.com'
    login_password = '01259'

    options = webdriver.ChromeOptions()
    options.add_argument('--headless')
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-dev-shm-usage')
    driver = webdriver.Chrome('chromedriver', options=options)
    try:
        driver.get(login_link)
        time.sleep(2)
    except:
        time.sleep(10)
    time.sleep(1)

    # enter email/password
    driver.find_element_by_xpath('//*[@id="login-form"]/section/div[1]/div[1]/input').send_keys(login_email)
    driver.find_element_by_xpath('//*[@id="login-form"]/section/div[2]/div[1]/div/input').send_keys(login_password)

    login_click = ActionChains(driver)
    login_click.click(driver.find_element_by_id('submit-login')).perform()

    # get all categories
    for key in sublime_bw_categories:
        category_name = key
        print(key + ' : ' + sublime_bw_categories[key])
        link_url = sublime_bw_categories[key]
        response_ = requests.get(url=link_url, headers=headers)
        data_soup = Soup(response_.text, "html.parser")

        pages = data_soup.find('ul', {'class:', 'page-list clearfix text-md-right text-xs-center'})
        page_length = len(pages.findAll('li'))
        page_length = pages.findAll('li')[page_length-2].text

        # go to each page inside category
        for i in range(int(page_length)):
            page_link = link_url + "?page="+str(i+1)
            print("page: " + page_link)
            page_response_ = requests.get(url=page_link, headers=headers)
            page_soup = Soup(page_response_.text, "html.parser")
            products = page_soup.find('div', {'class:', 'products'})
            products = products.find('div', {'class:', 'product_list grid plist-default'})
            products = products.find('div', {'class:', 'row'})

            for product in products.findAll('div', {'class:', 'ajax_block_product'}):
                product_page_link = product.find('a')['href']
                try:
                    # product_response_ = requests.get(
                    #     url=product_page_link,
                    #     headers=headers)
                    # product_soup = Soup(product_response_.text, "html.parser")

                    try:
                        driver.get(product_page_link)
                        time.sleep(2)
                    except:
                        time.sleep(10)
                    time.sleep(1)
                    product_soup = Soup(driver.page_source, "html.parser")

                    product_soup = product_soup.find('section', {'id': 'wrapper'})
                    nav_bar = product_soup.find('nav', {'class:', 'breadcrumb hidden-sm-down'})
                    nav_bar = nav_bar.find('ol')

                    # brand name
                    brand = nav_bar.findAll('li')[2].text.strip()

                    main_section = product_soup.find('section', {'id': 'main'})
                    main_section = main_section.find('div', {'class:', 'row'})

                    product_image = main_section.find('img', {'id': 'zoom_product'})['src']
                    product_name = main_section.find('h1', {'class:', 'h1 product-detail-name'}).text
                    product_manufacturer = brand.replace('Marca:', '')
                    product_reference = main_section.find('div', {'class:', 'product-reference'}).text.strip()
                    product_reference = product_reference.replace('Referencia:', '')

                    try:
                        product_prices = product_soup.find('div', {'class:', 'product-prices'})
                        regular_price = product_prices.find('div', {'class:', 'product-discount'}).text.strip()
                        sale_price = product_prices.find('div', {'class:', 'product-price h5 has-discount'})
                        sale_price = sale_price.find('div', {'class:', 'current-price'})
                        sale_price = sale_price.findAll('span')[0].text.strip()

                        stock = main_section.find('div', {'class:', 'product-quantities'})

                        stock_status = stock.find('label', {'class:', 'label'}).text

                        stock = stock.find('span').text
                        stock = stock.replace('Artículos', '')

                    except:
                        stock = ''
                        stock_status = ''

                    product_tag = product_soup.find('nav', {'class:', 'breadcrumb hidden-sm-down'})
                    product_tag = product_tag.find('ol')
                    slug_ = product_page_link.split('/')[4]
                    tags_ = ''
                    for tag in product_tag.findAll('li'):
                        tags_ = tags_ + tag.text.replace('\n', '') + ' | '

                    ws_sublime_bw.append(
                        ["", product_reference, "", product_name, category_name, tags_,
                         product_manufacturer, "", regular_price, "", "", regular_price,
                         sale_price, "", stock, "", stock_status, product_image, "",
                         "", "", "", product_page_link, "publish",
                         slug_])
                    wb_sublime_bw.save(product_sublime_bw)
                except:
                    pass
    driver.quit()


# method for scrapping brasily data
def get_brasily_belleza():

    # PART 1 here......
    link_url = 'https://www.brasilybelleza.com'
    response_ = requests.get(url=link_url, headers=headers)
    data_soup = Soup(response_.text, "html.parser")
    categories = data_soup.find('ul', {'class:', 'list-unstyled components'})
    for category in categories.findAll('li'):
        cat_key = category.find('a').text.strip()
        cat_link = link_url + category.find('a')['href']
        brasilybelleza_categories[cat_key] = cat_link

    for key in brasilybelleza_categories:
        print(key + ' : ' + brasilybelleza_categories[key])
        _id = brasilybelleza_categories[key].split('/')[6]
        print(_id)
        # if 'Ofertas hasta -50%' in key or 'Tratamiento Queratina' in key or 'Alisado Brasileño' in key \
        #         or 'Botox Capilar' in key or 'Champú Antiresiduos' in key or 'Champú Sin Sal' in key \
        #         or 'Champú Sin Sulfatos' in key or 'Mascarilla Capilar' in key:
        #     print('already...')
        #     pass
        # else:
        category_link = brasilybelleza_categories[key]

        options = webdriver.ChromeOptions()
        options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        driver = webdriver.Chrome('chromedriver', options=options)
        try:
            driver.get(category_link)
        except:
            time.sleep(10)
        time.sleep(1)
        html = driver.page_source
        time.sleep(2)
        while 'Ver más' in html:
            li_click = ActionChains(driver)
            li_click.click(driver.find_element_by_id(_id)).perform()
            time.sleep(10)
            html = driver.page_source
        data_soup = Soup(html, 'html.parser')
        products = data_soup.find('div', {'class:', 'row more_results_container'})
        try:
            for product in products.findAll('div', {'class:', 'col-md-3 col-sm-6 col-xs-6'}):
                product_detail_link = link_url + product.find('a')['href']
                print(product_detail_link)
                try:
                    # get product details
                    product_url = product_detail_link
                    response_ = requests.get(url=product_url, headers=headers)
                    data_soup = Soup(response_.text, "html.parser")
                    time.sleep(2)
                    # product details
                    product_title = data_soup.find('h1', {'id': 'product-name'}).text
                    product_image = data_soup.find('img', {'id': 'img-1'})['src']
                    image_files = data_soup.find('img', {'id': 'img-1'})['title'].replace(' ', '_')
                    image_title = data_soup.find('img', {'id': 'img-1'})['title']
                    image_alt = data_soup.find('img', {'id': 'img-1'})['alt']
                    short_description = data_soup.find('div',
                                                       {'class:', 'col-md-6 col-sm-6 col-xs-12 product'}).text
                    short_description = \
                    short_description.replace('Champú antiresiduos Amazon Keratin Aceite de Coco 118ml', '').split(
                        'Referencia:', 1)[0].strip()

                    meta_datas = data_soup.find('ul', {'class:', 'product-list'})
                    reference = meta_datas.findAll('li')[0].text.strip().replace('Referencia:', '')
                    brand = meta_datas.findAll('li')[1].text.strip()
                    availability = meta_datas.findAll('li')[2].text.strip()

                    price = data_soup.find('div', {'class:', 'price-box-price'})
                    regular_price = price.find('span', {'class:', 'old-price'}).text.strip()
                    sale_price = data_soup.find('div', {'class:', 'price-box-price'}).text.strip().split('€')[0]
                    price_weight = data_soup.find('div', {'class:', 'price-weight'}).text.strip()
                    post_content = data_soup.find('div', {'id': 'product-description'})
                    slug = product_detail_link.split('/')[6]

                    p_tag = data_soup.find('ul', {'class:', 'breadcrumb'})

                    p_tag = p_tag.text.replace('\n', '| ')
                    p_tag = p_tag[1:]

                    if 'No disponible' in availability:
                        manage_stock = 'no'
                    else:
                        manage_stock = 'yes'

                    try:
                        availability = availability.replace('Disponibilidad:', '')
                    except:
                        pass

                    ws_brasilybelleza.append(
                        ["", reference, "", product_title, 'key', p_tag,
                         brand, str(post_content.text), regular_price, price_weight, short_description,
                         regular_price, sale_price, "taxable", availability, manage_stock, availability,
                         product_image,
                         image_files, image_title, image_title, image_alt, product_url, "publish", slug])

                    wb_brasilybelleza.save(product_brasilybelleza)
                    time.sleep(2)
                except:
                    pass
        except:
            pass


if __name__ == '__main__':

    try:
        get_dismay()
        time.sleep(120)
    except:
        time.sleep(10)
        pass
    try:
        get_sublime_bw()
        time.sleep(120)
    except:
        time.sleep(10)
        pass
    try:
        get_brasily_belleza()
    except:
        time.sleep(10)
        pass
