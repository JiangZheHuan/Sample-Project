from django.urls import path
from .views import *

urlpatterns = [
    path('get_spot/', SpotView.as_view(), name='spot'),
    path('get_future/', FutureView.as_view(), name='future'),
    ]