from django.db import models
from django.utils import timezone
# Create your models here.


class BaseModel(models.Model):
    """
    Base model which extends in all models to inherit common fields.
    """
    is_deleted = models.BooleanField(null=False, default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True

    def delete(self):
        self.is_deleted = True
        self.save()

    def restore(self):
        self.is_deleted = False
        self.save()


class Future(BaseModel):
    """
    Future model with inherited Base model
    """
    Trans_Date=models.DateTimeField(default=timezone.now())
    Pairs=models.CharField(max_length=100 , null=True,blank=True)
    Direction=models.CharField(max_length=100 , null=True,blank=True)
    Leverage=models.CharField(max_length=100 , null=True,blank=True)
    Entry_1=models.CharField(max_length=100 , null=True,blank=True)
    Entry_2=models.CharField(max_length=100 , null=True,blank=True)
    Entry_3=models.CharField(max_length=100 , null=True,blank=True)
    Entry_4=models.CharField(max_length=100 , null=True,blank=True)
    Entry_5=models.CharField(max_length=100 , null=True,blank=True)
    Stop_Loss_1=models.CharField(max_length=100 , null=True,blank=True)
    TP_1=models.CharField(max_length=100 , null=True,blank=True)
    TP_2=models.CharField(max_length=100 , null=True,blank=True)
    TP_3=models.CharField(max_length=100 , null=True,blank=True)
    TP_4=models.CharField(max_length=100 , null=True,blank=True)
    TP_5=models.CharField(max_length=100 , null=True,blank=True)
    TP_6=models.CharField(max_length=100 , null=True,blank=True)
    TP_7=models.CharField(max_length=100 , null=True,blank=True)
    TP_8=models.CharField(max_length=100 , null=True,blank=True)
    TP_9=models.CharField(max_length=100 , null=True,blank=True)
    TP_10=models.CharField(max_length=100 , null=True,blank=True)
    TP_11=models.CharField(max_length=100 , null=True,blank=True)
    TP_12=models.CharField(max_length=100 , null=True,blank=True)
    TP_13=models.CharField(max_length=100 , null=True,blank=True)
    TP_14=models.CharField(max_length=100 , null=True,blank=True)
    TP_15=models.CharField(max_length=100 , null=True,blank=True)
    Stop_Loss_2=models.CharField(max_length=100 , null=True,blank=True)

    class Meta:
        db_table = 'future'
        verbose_name = 'future'
        verbose_name_plural = 'futures'


class Spot(BaseModel):
    """
    Spot model with inherited Abstract User
    """
    Trans_Date=models.DateTimeField(default=timezone.now())
    Pairs=models.CharField(max_length=100 , null=True,blank=True)
    Entry_1=models.CharField(max_length=100 , null=True,blank=True)
    Entry_2=models.CharField(max_length=100 , null=True,blank=True)
    Entry_3=models.CharField(max_length=100 , null=True,blank=True)
    Entry_4=models.CharField(max_length=100 , null=True,blank=True)
    Entry_5=models.CharField(max_length=100 , null=True,blank=True)
    Stop_Loss_1=models.CharField(max_length=100 , null=True,blank=True)
    TP_1=models.CharField(max_length=100 , null=True,blank=True)
    TP_2=models.CharField(max_length=100 , null=True,blank=True)
    TP_3=models.CharField(max_length=100 , null=True,blank=True)
    TP_4=models.CharField(max_length=100 , null=True,blank=True)
    TP_5=models.CharField(max_length=100 , null=True,blank=True)
    TP_6=models.CharField(max_length=100 , null=True,blank=True)
    TP_7=models.CharField(max_length=100 , null=True,blank=True)
    TP_8=models.CharField(max_length=100 , null=True,blank=True)
    TP_9=models.CharField(max_length=100 , null=True,blank=True)
    TP_10=models.CharField(max_length=100 , null=True,blank=True)
    TP_11=models.CharField(max_length=100 , null=True,blank=True)
    TP_12=models.CharField(max_length=100 , null=True,blank=True)
    TP_13=models.CharField(max_length=100 , null=True,blank=True)
    TP_14=models.CharField(max_length=100 , null=True,blank=True)
    TP_15=models.CharField(max_length=100 , null=True,blank=True)
    Stop_Loss_2=models.CharField(max_length=100 , null=True,blank=True)

    class Meta:
        db_table = 'spot'
        verbose_name = 'spot'
        verbose_name_plural = 'spots'


