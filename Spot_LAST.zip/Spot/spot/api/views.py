from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import authentication, permissions
from django.contrib.auth.models import User
# Create your views here.
from rest_framework.views import APIView
from rest_framework.response import Response
from .models import *
import more_itertools as mit
from rest_framework.parsers import BaseParser


class PlainTextParser(BaseParser):
    """
    Plain text parser.
    """
    media_type = 'text/plain'

    def parse(self, stream, media_type=None, parser_context=None):
        """
        Simply return a string representing the body of the request.
        """
        return stream.read()

def spot_parse_func(data):
    dumy_obj={}
    pairs=[s for s in data if "$" in s]
    if any("Entry" in s for s in data):
        entry = [s for s in data if "Entry" in s]
    if any("Buy" in s for s in data):
        entry = [s for s in data if "Buy" in s]
    tp = [s for s in data if "TP" in s]
    sl = [s for s in data if "SL" in s]
    dumy_obj['Pairs']=pairs[0].replace('\n','')
    dumy_obj['Stop_Loss_1']=sl[0].replace('\n','').split(':')[1].split(' ')[-1]
    if any("-" in s for s in entry):
        entries = entry[0].split(':')[1].replace('\n', '').split('-')
    if any("/" in s for s in entry):
        entries = entry[0].split(':')[1].replace('\n', '').split('/')
    if any("-" in s for s in tp):
        tps=tp[0].split(':')[1].replace('\n','').replace(' ','').split('-')
    if any("/" in s for s in tp):
        tps=tp[0].split(':')[1].replace('\n','').replace(' ','').split('/')
    i=1
    for _ in entries:
        dumy_obj['Entry_'+str(i)]=_
        i= i+1
    j=1
    for _ in tps:
        dumy_obj['TP_'+str(j)]=_
        j= j+1

    m = Spot(**dumy_obj)
    r=m.save()
    return r


def future_parse_func(data):

    dumy_obj={}
    pairs=[s for s in data if "$" in s]
    if any("Short" in s for s in data):
        # direction = [s for s in data if "Short" in s]
        dumy_obj['Direction'] = "Short"
    if any("Long" in s for s in data):
        # direction = [s for s in data if "Long" in s]
        dumy_obj['Direction'] = "Long"
    if any("Entry" in s for s in data):
        entry = [s for s in data if "Entry" in s]
    if any("Buy" in s for s in data):
        entry = [s for s in data if "Buy" in s]
    tp = [s for s in data if "TP" in s]
    sl = [s for s in data if "SL" in s]
    dumy_obj['Pairs']=pairs[0].replace('\n','')

    dumy_obj['Stop_Loss_1']=sl[0].replace('\n','').split(':')[1].split(' ')[-1]
    if any("-" in s for s in entry):
        entries=entry[0].split(':')[1].replace('\n','').split('-')
    if any("/" in s for s in entry):
        entries=entry[0].split(':')[1].replace('\n','').split('/')
    if any("-" in s for s in tp):
        tps=tp[0].split(':')[1].replace('\n','').replace(' ','').split('-')
    if any("/" in s for s in tp):
        tps=tp[0].split(':')[1].replace('\n','').replace(' ','').split('/')
    i=1
    for _ in entries:
        dumy_obj['Entry_'+str(i)]=_
        i= i+1
    j=1
    for _ in tps:
        dumy_obj['TP_'+str(j)]=_
        j= j+1

    m = Future(**dumy_obj)
    r=m.save()
    return r


class SpotView(APIView):

    parser_classes = [PlainTextParser]

    def post(self, request, format=None):
        """
        Return a list of spot.
        """

        lines = request.data.decode("utf-8").split('\n')
        pairs = [s for s in lines if "$" in s]
        indexes=[]
        for _ in pairs:
            indexes.append(lines.index(_))
        indexes.append(len(lines))

        for i in range(len(indexes)-1):
            spot_parse_func((lines[indexes[i]:indexes[i+1]]))

        return Response({'message':"object created successfully"})


class FutureView(APIView):

    parser_classes = [PlainTextParser]

    def post(self, request, format=None):
        """
        Return a list of spot.
        """
        lines = request.data.decode("utf-8").split('\n')
        pairs = [s for s in lines if "$" in s]
        indexes = []
        for _ in pairs:
            indexes.append(lines.index(_))
        indexes.append(len(lines))

        for i in range(len(indexes) - 1):
            future_parse_func((lines[indexes[i]:indexes[i + 1]]))

        return Response({'message':"object created successfully"})