from django.contrib import admin
from .models import *
# Register your models here.


class SpotInline(admin.ModelAdmin):
    list_display = ('Pairs',)


class FutureInline(admin.ModelAdmin):
    list_display = ('Pairs',)


admin.site.register(Spot,SpotInline)
admin.site.register(Future,FutureInline)