const mysql = require("mysql");

const { DB_NAME, DB_PASSWORD, DB_PORT, DB_USER, HOST } = require("./env_config");


module.exports.db = mysql.createPool({
    host: HOST,
    database: DB_NAME,
    password: DB_PASSWORD,
    port: DB_PORT,
    user: DB_USER
});

