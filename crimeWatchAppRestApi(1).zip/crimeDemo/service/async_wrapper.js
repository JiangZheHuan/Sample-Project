const asynWraper = (fn) => {
  return async (req, res, next) => {
    try {
      await fn(req, res, next);
    } catch (e) {
      console.log(e);
      return next(e);
    }
  };
};

module.exports = asynWraper;
