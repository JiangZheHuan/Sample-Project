
const custome_error = require("./custome_error_creator");

const error_handler = (err, req, res, next) => {

    if (err instanceof custome_error) {
        return res.status(err.statusCode).json({
            "s": 0,
            "m": err.message
        });
    }

    return res.status(500).json({
        "s": 0,
        "m": "something went wrong internally"
    });

}

module.exports = error_handler;