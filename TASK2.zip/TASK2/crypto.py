# crypto.py
# --------------
# COMP1005 - Winter 2021

## Student: 
## ID:
## Comments:
##
##
##
##


# you are NOT expected to know how this function works. 
def decrypt(ciphertext: str, shift: int, alphabet: str) -> str:
    '''Decrypts the given ciphertext using the shift cipher with the provided shift and alphabet.
      
       pre-condition: alphabet has no repeated characters in it
    '''
    
    size = len(alphabet)
    
    # Create a look up table for decryption using a dictionary 
    # (we'll learn about them later!)
    # Each letter will be mapped to its position in the alphabet list
    lookUp = dict()  # empty dictionary
    for index in range(size):
        lookUp[alphabet[index]] = index

    # decrypt the message character by character 
    # storing the resulting characters in a list
    # use list cmprehension to create this list
    # (we'll learn about that later!)
    plaintext = [ alphabet[(lookUp[c]-shift) % size] for c in ciphertext]

    # join all the elements of the list together (and output result)
    return "".join(plaintext)

