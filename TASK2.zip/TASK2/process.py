# process.py
# --------------
# COMP1005 - Winter 2021


## Student: 
## ID:
## Comments:
##
##
##
##



# Make sure the data.csv file is saved in the same directory as this file.
# If you are using VS Code, you must change the settings so that it can find 
# the file when it tries to open it.
# Go to Preferences -> Settings
#       Once in Settings, use the search bar to search for InFileDir
#       Check the box for  "Python -> Terminal : Execute In File Dir"



####
####  add your functions above the main method
####






# This function controls the program
def main():
    fname = 'data.csv'           # filename
    
    print("...opening file " + fname + " for reading")
    file = open(fname, 'r')      # open the file for reading

    print("...reading contents of file")
    data = file.readlines()      # read entire contents of file into list of strings
                                 # each line in the file is one string

    print("...closing file " + fname)
    file.close()                 # close the file now that we are done with it

    print("...data is...")
    for line in data:
        print(line, end='')

    ##
    ## data now has a list as needed for your functions.
    ##

    ## test your findByDomain() and emailsByAge() functions
    #users = findByDomain('carleton.ca', data)
    #print(users)
    #stats = emailsByAge(10,20,data)
    #print(stats)




###########################################################################
#
# Do NOT change the code below this
#
###########################################################################

# This if statement is needed so that when you "run" this program it will 
# automatically call the main function.
# If you load this function as a module it will not call main()
if __name__ == "__main__":
    main()