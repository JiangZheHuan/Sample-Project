function [ON,net,ExtraOn] = Scheduling(net,CH,r,k,Groups,USE,R,D)

ExtraOn = false(1,size(net,2));

if USE
    
    ON_group = mod(r,k)+1; % The choosen group to be ON this round
    ON_CH = find((Groups == ON_group) & CH & ~D); % the cluster heads that are ON
    OFF_CH = find((Groups ~= ON_group) & CH & ~D); % the cluster heads that are off    
    
    % Extra-On Rule
    X = net(2,:); Y = net(3,:);
    len = length(ON_CH);
    for i=1:len-1
        sx = X(ON_CH(i+1:len)); ix = X(ON_CH(i));
        sy = Y(ON_CH(i+1:len)); iy = Y(ON_CH(i));
        d = sqrt((sx - ix).^2 + (sy - iy).^2);
        d = min(d);
        if d > R
            sx = X(OFF_CH);
            sy = Y(OFF_CH);
            d = sqrt((sx - ix).^2 + (sy - iy).^2);
            [~,d] = min(d);
            % remove it from off cluster heads and put it in ON ones
            if ~isempty(d)
            ON_CH(end+1) = OFF_CH(d);
            
            ExtraOn(OFF_CH(d)) = true;
            
            
            OFF_CH(d) = [];
            end
        end
    end
    
    % Turning ON the cluster heads and their children
    ON = false(1,size(net,2));
    for i=1:length(ON_CH)
        c = net(1,ON_CH(i));
        ON(net(1,:)==c) = true;
    end
    
    % remove OFF nodes from clustering
    net(1,~ON) = 0;
    
    
else
    ON = true(1,size(net,2));
end



