function W = packTheta(Theta)
%PACKTHETA given a cell containing weights for each layer
%  Theta{1}, Theta{2}, etc.. for each layer
%  returns a vector w containing all weights packed 
W = [];
for i=1:size(Theta,1)
    W = [W;reshape(Theta{i,:},[],1)];
end

end