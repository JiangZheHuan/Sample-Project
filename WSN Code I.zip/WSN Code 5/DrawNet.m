function net = DrawNet(net,N,CH,D,SX,SY,Xcov1,Ycov1,ON,ON_pr,USE_schedule)
cla
% This function plots the shape of the network
% showing all nodes and its status
% If there is cluster map [(3-D matrix)
% where first and second dimensions are 
% x and y postions of cluster border
% and the third dimension is number of clusters]
% then the function plots those clusters in green lines

% Determine each node type
m = max(net(4,:));
Tsym = '<osd^phv>';
TCol = 'mbkc';
for i = 1:m
    idxT(i,:) = net(4,:)==i;
end

% OFF nodes
if ~(sum(~ON)==0)
    for i = 1:m
        plot(net(2,~ON&idxT(i,:)&~D),net(3,~ON&idxT(i,:)&~D),...
            ['y',Tsym(mod(i,8)+1)],'MarkerSize',...
            7,'MarkerFaceColor','y'); hold on;
    end
end

% normal nodes
for i = 1:m
plot(net(2,ON&~CH&~D&idxT(i,:)),net(3,ON&~CH&~D&idxT(i,:)),...
    [TCol(mod(i,4)+1),Tsym(mod(i,8)+1)],'MarkerSize',...
    7,'MarkerFaceColor',TCol(mod(i,4)+1)); hold on;
end

% dead nodes
for i = 1:m
plot(net(2,D&idxT(i,:)),net(3,D&idxT(i,:)),...
    [TCol(mod(i,4)+1),Tsym(mod(i,8)+1)],'MarkerSize',7);
end

% Cluster heads
for i = 1:m
plot(net(2,CH&idxT(i,:)),net(3,CH&idxT(i,:)),...
    [TCol(mod(i,4)+1),Tsym(mod(i,8)+1)],'MarkerSize',...
    7,'MarkerFaceColor','r');
end

% The sink
for i=1:length(SX)
    scatter(SX(i),SY(i),100,'bo','filled')
    text(SX(i)+2,SY(i)+2,'Sink','FontSize',11,'VerticalAlignment','Baseline');
end

% titles
s = int2str((1:N)');
text(net(2,:)+1,net(3,:)+1,s,'FontSize',8,'VerticalAlignment','Baseline');
xlabel('\it x \rm [m] \rightarrow');
ylabel('\it y \rm [m] \rightarrow');

% Show data connections
idx = net(1,:); Clust = unique(idx); Clust(Clust==0)=[];
X = net(2:3,:); X = X';
for i=1:length(Clust)
    sx = X(Clust(i+1:end),1);
    sy = X(Clust(i+1:end),2);
    tmp= idx==Clust(i); tmp=X(tmp,:);
    for j=1:size(tmp,1)
        plot([tmp(j,1),X(Clust(i),1)],[tmp(j,2),X(Clust(i),2)],'-','Color','g')
    end
    
    d = sqrt((sx - X(Clust(i),1)).^2 + (sy - X(Clust(i),2)).^2);
    if ~isempty(d)
        [~,d] = min(d);
    end
    plot([sx(d),X(Clust(i),1)],[sy(d),X(Clust(i),2)],'--','Color','b')
    
    
end
d = sqrt((SX - X(Clust,1)).^2 + (SY - X(Clust,2)).^2);
[~,d] = min(d);
plot([SX,X(Clust(d),1)],[SY,X(Clust(d),2)],'--','Color','b')

% Show covered sensing region
axis manual
plot(Xcov1,Ycov1,'--r')

if USE_schedule
% Neural network prediction
% plot(net(2,ON_pr==3),net(3,ON_pr==3),'ro',...
%     'MarkerSize',12,'LineWidth',2);
plot(net(2,ON_pr==2),net(3,ON_pr==2),'go',...
    'MarkerSize',12,'LineWidth',2);
end

hold off


