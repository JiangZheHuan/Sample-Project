from utils.datetime import time
from utils.setting import setting
from utils.measuretime import measuretime
setting.loadsettings()
from utils.log import log
