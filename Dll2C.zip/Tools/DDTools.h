/*******************************************************************************
  File Name   : DLL Decompile Tools
  Author      : Zhixian Lin
  Date        : 2017
  Description : The tools for decompile work.
  Copyright   : www.dll-decompiler.com, all rights reserved.
  E-mail      : support@dll-decompiler.com
*******************************************************************************/

#pragma once

#ifndef ASSERT
#ifdef _DEBUG
#define ASSERT(expr) if(!(expr)){__asm int 3}
#else
#define ASSERT(expr)
#endif
#endif

#define DB(x) __asm _emit x

#define JMP_TABLE_BEGIN(tableName,indexReg) __asm jmp dword ptr [offset tableName + indexReg*8 + 1] __asm tableName:
#define JT_ITEM(destAddr) __asm push destAddr DB(0xCC) DB(0xCC) DB(0xCC) //Jmp table item
#define JMP_TABLE_END()

/*
	Lin's Stack which for decompile work, invented by Zhixian Lin in May 2021.
*/
class _LinStack
{
protected:
	DWORD m_esp;
	DWORD m_oldEsp;

	DWORD m_saveEsp;
	DWORD m_saveEbp;
	
	FARPROC m_fun;

#ifdef _DEBUG
	DWORD m_argCount; //STDCALL argument count, will be update after every Invoke.
#endif

	DWORD m_stkTop;
	DWORD m_stkBottom;
public:
	operator DWORD&(){return m_esp;}

	template <class T> void Push(T val)
	{
#ifdef _DEBUG
		if(m_esp <= m_stkTop)
		{
			MessageBox(NULL,_T("LinStack size is not enough, please increase the size!"),
				_T("Error"),MB_OK | MB_ICONERROR);
			ASSERT(0);
			return;
		}
#endif

		m_esp -= sizeof(void*);
		*(DWORD*)m_esp = (DWORD)val;
	}

	DWORD Pop()
	{
		DWORD retV = *(DWORD*)m_esp;
		m_esp += sizeof(void*);

		ASSERT(m_esp <= m_stkBottom);

		return retV;
	}

	INT GetUsedSize()const
	{
		ASSERT(m_stkBottom >= m_esp);

		return (m_stkBottom - m_esp) / sizeof(void*);
	}

	static DWORD Invoke(INT argCount, FARPROC fun, _LinStack* vEsp);
};

template <INT StackSize> class LinStack : public _LinStack
{
protected:
	void* m_stk[StackSize];
public:
	LinStack()
	{
		m_stkTop = (DWORD)&m_stk[0];
		m_stkBottom = m_stkTop + StackSize * sizeof(void*);

		m_esp = m_stkBottom;
	}	
};

#define INVOKE(argCount, fun) _LinStack::Invoke(argCount, (FARPROC)fun, &vEsp)

class TlsIndex
{
private:
	DWORD m_tlsIndex;
public:
	TlsIndex()
	{
		m_tlsIndex = TlsAlloc();
	}

	~TlsIndex();

	operator DWORD()const{return m_tlsIndex;}
};

enum Register{
	REG_UNK = 0,
	R32_EAX = 7,
	R32_EBX = 7*2,
	R32_ECX = 7*3,
	R32_EDX = 7*4,
	R32_ESI = 7*5,
	R32_EDI = 7*6,
	R32_EBP = 7*7,
};

struct RegVal
{
	Register reg;
	DWORD value;
};

class RegValues
{
public:
	RegVal regValues[7];

	RegValues(Register r1 = REG_UNK,DWORD v1 = 0,Register r2 = REG_UNK,DWORD v2 = 0,
			Register r3 = REG_UNK,DWORD v3 = 0,Register r4 = REG_UNK,DWORD v4 = 0,
			Register r5 = REG_UNK,DWORD v5 = 0,Register r6 = REG_UNK,DWORD v6 = 0,
			Register r7 = REG_UNK,DWORD v7 = 0)
	{
		memcpy(&regValues,&r1,sizeof(regValues));
	}
};

DWORD InvokeFunEx(LPCVOID fun, RegValues regValues);
DWORD InvokeFunEx(LPCVOID fun, RegValues regValues, DWORD arg1);
DWORD InvokeFunEx(LPCVOID fun, RegValues regValues, DWORD arg1,DWORD arg2);
DWORD InvokeFunEx(LPCVOID fun, RegValues regValues, DWORD arg1,DWORD arg2,DWORD arg3);
DWORD InvokeFunEx(LPCVOID fun, RegValues regValues, DWORD arg1,DWORD arg2,DWORD arg3,DWORD arg4);

inline DWORD _InvokeFunEx(LPCVOID fun,RegValues& regValues)
{
	return InvokeFunEx(fun,regValues);
}

template <class T1> DWORD _InvokeFunEx(LPCVOID fun, RegValues& regValues, T1 arg1)
{
	return InvokeFunEx(fun,regValues,(DWORD)arg1);
}

template <class T1,class T2> DWORD _InvokeFunEx(LPCVOID fun, RegValues& regValues, T1 arg1,T2 arg2)
{
	return InvokeFunEx(fun,regValues,(DWORD)arg1,(DWORD)arg2);
}

template <class T1,class T2,class T3> DWORD _InvokeFunEx(LPCVOID fun, RegValues& regValues, T1 arg1,T2 arg2,T3 arg3)
{
	return InvokeFunEx(fun,regValues,(DWORD)arg1,(DWORD)arg2,(DWORD)arg3);
}

template <class T1,class T2,class T3,class T4> 
	DWORD _InvokeFunEx(LPCVOID fun, RegValues& regValues, T1 arg1,T2 arg2,T3 arg3,T4 arg4)
{
	return InvokeFunEx(fun,regValues,(DWORD)arg1,(DWORD)arg2,(DWORD)arg3,(DWORD)arg4);
}

#define INVOKE_EX(fun, ...) _InvokeFunEx((LPCVOID)fun,__VA_ARGS__)

DWORD InvokeFunExC(LPCVOID fun, RegValues regValues);
DWORD InvokeFunExC(LPCVOID fun, RegValues regValues, DWORD arg1);
DWORD InvokeFunExC(LPCVOID fun, RegValues regValues, DWORD arg1,DWORD arg2);
DWORD InvokeFunExC(LPCVOID fun, RegValues regValues, DWORD arg1,DWORD arg2,DWORD arg3);
DWORD InvokeFunExC(LPCVOID fun, RegValues regValues, DWORD arg1,DWORD arg2,DWORD arg3,DWORD arg4);

inline DWORD _InvokeFunExC(LPCVOID fun,RegValues& regValues)
{
	return InvokeFunExC(fun,regValues);
}

template <class T1> DWORD _InvokeFunExC(LPCVOID fun, RegValues& regValues, T1 arg1)
{
	return InvokeFunExC(fun,regValues,(DWORD)arg1);
}

template <class T1,class T2> DWORD _InvokeFunExC(LPCVOID fun, RegValues& regValues, T1 arg1,T2 arg2)
{
	return InvokeFunExC(fun,regValues,(DWORD)arg1,(DWORD)arg2);
}

template <class T1,class T2,class T3> DWORD _InvokeFunExC(LPCVOID fun, RegValues& regValues, T1 arg1,T2 arg2,T3 arg3)
{
	return InvokeFunExC(fun,regValues,(DWORD)arg1,(DWORD)arg2,(DWORD)arg3);
}

template <class T1,class T2,class T3,class T4> 
	DWORD _InvokeFunExC(LPCVOID fun, RegValues& regValues, T1 arg1,T2 arg2,T3 arg3,T4 arg4)
{
	return InvokeFunExC(fun,regValues,(DWORD)arg1,(DWORD)arg2,(DWORD)arg3,(DWORD)arg4);
}

#define INVOKE_EX_C(fun, ...) _InvokeFunExC((LPCVOID)fun,__VA_ARGS__)

struct _EH4_SCOPETABLE_RECORD {
	DWORD EnclosingLevel;
	LPVOID FilterFunc;
	LPVOID HandlerFunc;
};

struct _EH4_SCOPETABLE {
	UINT GSCookieOffset;
	UINT GSCookieXOROffset;
	UINT EHCookieOffset;
	UINT EHCookieXOROffset;
	_EH4_SCOPETABLE_RECORD ScopeRecord[1];
};

#define SEH_SET_FILTER(_tbl,_index,_fFilter,_fHandler) \
	__asm mov dword ptr [offset _tbl + 16 + _index*12 + 4], offset _fFilter \
	__asm mov dword ptr [offset _tbl + 16 + _index*12 + 8], offset _fHandler

void __stdcall imul8(CHAR val, DWORD* vEaxEdx);
void __stdcall imul32(INT val, DWORD* vEaxEdx);
void __stdcall idiv8(CHAR val, DWORD* vEaxEdx);
void __stdcall idiv32(INT val, DWORD* vEaxEdx);

DWORD MagicDiv7(INT val, INT nShift);
DWORD MagicDiv100(INT val, INT nShift);